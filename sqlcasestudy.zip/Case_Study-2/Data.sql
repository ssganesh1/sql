/*inserting data into menu table.(TYUC001-a)*/
insert into menu (item_name,price,active,date_of_launch,category,free_delivery)
values('Sandwich',99.00,'Yes','2017-03-15','Main Course','Yes'),
('Burger',129.00,'Yes','2017-12-23','Main Course','No'),
('Pizza',149.00,'Yes','2017-08-21','Main Course','No'),
('French Fries',57.00,'No','2017-07-02','Starter','Yes'),
('Chocolate',32.00,'Yes','2022-11-02','Desserts','Yes');

/*getting all menu items.(TYUC001-b)*/
select item_name,concat('Rs. ',price) as price,active,date_of_launch,category,free_delivery from menu;

/*getting all menu items which are before launch date and is active.(TYUC002)*/
select item_name,free_delivery,concat('Rs. ',price) as price,category from menu
where date_of_launch<now()
and active='Yes';

/*getting a menu item based on Menu Item Id from menu table.(TYUC003-a)*/
select item_name,concat('Rs. ',price) as price,active,date_of_launch,category,free_delivery from menu 
where item_id=@item_id;

/*updating all column values based on menu item id in menu table.(TYUC003-b)*/
update menu
set item_name=@item_name,
price=@price,
active=@active,
date_of_launch=@date_of_launch,
category=@category,
free_delivery=@free_delivery
where item_id=@item_id;

/*inserting username(TYUC004)*/
insert into user (user_name) 
values('Johny'),('Danny');

/*inserting items into cart with no items(TYUC004)*/
insert into cart (item_id,user_id)
values(null,1);

/*inserting items into cart with atleast 3 items(TYUC004)*/
insert into cart (item_id,user_id)
values(1,2),(2,2),(3,2);

/*getting all menu items in a particular user’s cart(TYUC005-a)*/
select m.item_name,m.free_delivery,concat('Rs. ',m.price) as price from menu m 
join cart c on m.item_id=c.item_id
join user u on c.user_id=u.user_id
where c.user_id=@user_id; 

/* getting the total price of all menu items in a particular user’s cart(TYUC005-b)*/
select concat('Rs. ',cast(sum(m.price) as char)) as total from menu m 
join cart c on m.item_id=c.item_id
join user u on c.user_id=u.user_id
where c.user_id=@user_id;

/* removing a menu items from Cart based on User Id and Menu Item Id*/
delete from cart 
where user_id=@user_id
and item_id=@item_id;
